
<?php
session_start();

// Bahasa default
$lang = $_SESSION['lang'] ?? 'id';

// Pilihan bahasa
if (isset($_GET['lang'])) {
    $lang = $_GET['lang'] === 'en' ? 'en' : 'id';
    $_SESSION['lang'] = $lang;

    header("Location: index.php");
    exit;
}

// Memanggil file bahasa
require_once "languages/" . $lang . ".php";
?>

<!DOCTYPE html>
<html lang="<?= $lang ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>MySpace - Your Personal Life Companion</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <!-- CSS MySpace -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container">

        <a class="navbar-brand" href="index.php">
            My<span>Space.</span>
        </a>

        <button class="navbar-toggler" type="button"
            data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarMenu">

            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#home"><?= $text['home'] ?></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#features"><?= $text['features'] ?></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#about"><?= $text['about'] ?></a>
                </li>
            </ul>

            <div class="navbar-actions">
                <select class="language-select"
                    onchange="window.location.href='?lang='+this.value">
                    <option value="id" <?= $lang == 'id' ? 'selected' : '' ?>>ID</option>
                    <option value="en" <?= $lang == 'en' ? 'selected' : '' ?>>EN</option>
                </select>

                <a href="login.php" class="btn-login">
                    <?= $text['login'] ?>
                </a>

                <a href="register.php" class="btn-register">
                    <?= $text['register'] ?>
                </a>
            </div>

        </div>
    </div>
</nav>


<!-- HERO SECTION -->
<section class="hero" id="home">
    <div class="container">
        <div class="row align-items-center">

            <div class="col-lg-6 hero-content">

                <span class="hero-label">
                    YOUR PERSONAL LIFE COMPANION
                </span>

                <h1>
                    <?= $text['hero_title'] ?>
                    <span><?= $text['hero_highlight'] ?></span>
                </h1>

                <p>
                    <?= $text['hero_description'] ?>
                </p>

                <div class="hero-buttons">
                    <a href="register.php" class="btn-primary-custom">
                        <?= $text['get_started'] ?>
                        <i class="fa-solid fa-arrow-right"></i>
                    </a>

                    <a href="#features" class="btn-secondary-custom">
                        <?= $text['explore'] ?>
                    </a>
                </div>

                <div class="hero-note">
                    <i class="fa-solid fa-heart"></i>
                    <?= $text['hero_note'] ?>
                </div>

            </div>

            <div class="col-lg-6 hero-image">
                <div class="hero-card">
                    <div class="hero-card-icon">
                        <i class="fa-solid fa-heart"></i>
                    </div>

                    <h3>MySpace</h3>
                    <p>Your life, your space.</p>

                    <div class="mini-feature">
                        <i class="fa-solid fa-wallet"></i>
                        <span>My Finance</span>
                    </div>

                    <div class="mini-feature">
                        <i class="fa-solid fa-calendar-check"></i>
                        <span>My Daily</span>
                    </div>

                    <div class="mini-feature">
                        <i class="fa-solid fa-star"></i>
                        <span>Self Growth</span>
                    </div>

                    <div class="hero-decoration">♡</div>
                </div>
            </div>

        </div>
    </div>
</section>


<!-- FEATURES SECTION -->
<section class="features-section" id="features">
    <div class="container">

        <div class="section-heading">
            <span>EXPLORE MYSPACE</span>
            <h2><?= $text['features_title'] ?></h2>
            <p><?= $text['features_description'] ?></p>
        </div>

        <div class="row g-4">

            <?php foreach ($text['feature_items'] as $feature): ?>
            <div class="col-md-6 col-lg-4">
                <div class="feature-card">

                    <div class="feature-icon">
                        <i class="<?= htmlspecialchars($feature['icon']) ?>"></i>
                    </div>

                    <h4><?= htmlspecialchars($feature['title']) ?></h4>

                    <p><?= htmlspecialchars($feature['description']) ?></p>

                </div>
            </div>
            <?php endforeach; ?>

        </div>
    </div>
</section>


<!-- ABOUT SECTION -->
<section class="about-section" id="about">
    <div class="container text-center">

        <span>ABOUT MYSPACE</span>

        <h2><?= $text['about_title'] ?></h2>

        <p><?= $text['about_description'] ?></p>

        <a href="register.php" class="btn-primary-custom">
            <?= $text['get_started'] ?>
            <i class="fa-solid fa-arrow-right"></i>
        </a>

    </div>
</section>


<!-- FOOTER -->
<footer class="footer">
    <div class="container text-center">
        <h3>My<span>Space.</span></h3>
        <p>Your Personal Life Companion</p>
        <small>© <?= date('Y') ?> MySpace. All rights reserved.</small>
    </div>
</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>

</body>
</html>
