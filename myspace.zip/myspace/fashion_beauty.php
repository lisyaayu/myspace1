
<?php
session_start();
require_once "config/database.php";

// =====================================
// 1. PEMERIKSAAN LOGIN
// =====================================

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

// =====================================
// 2. FUNGSI KEAMANAN
// =====================================

function e($value) {
    return htmlspecialchars(
        (string)($value ?? ""),
        ENT_QUOTES,
        "UTF-8"
    );
}

function safeUrl($url) {
    $url = trim((string)($url ?? ""));

    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return "";
    }

    $scheme = strtolower(
        parse_url($url, PHP_URL_SCHEME) ?? ""
    );

    if (!in_array($scheme, ["http", "https"], true)) {
        return "";
    }

    return $url;
}

// =====================================
// 3. AMBIL KATEGORI AKTIF
// =====================================

$categories = [];

$query = mysqli_query(
    $conn,
    "SELECT id, slug, name, description, image
     FROM fashion_beauty_categories
     WHERE is_active = 1
     ORDER BY sort_order ASC, id ASC"
);

if ($query) {
    while ($row = mysqli_fetch_assoc($query)) {
        $row["links"] = [];
        $categories[$row["id"]] = $row;
    }
}

// =====================================
// 4. AMBIL TAUTAN AKTIF
// =====================================

$linkQuery = mysqli_query(
    $conn,
    "SELECT category_id, link_type, link_label, url
     FROM fashion_beauty_links
     WHERE is_active = 1
     ORDER BY category_id ASC, id ASC"
);

if ($linkQuery) {
    while ($link = mysqli_fetch_assoc($linkQuery)) {
        $categoryId = $link["category_id"];

        if (isset($categories[$categoryId])) {
            $categories[$categoryId]["links"][$link["link_type"]] = $link;
        }
    }
}

// =====================================
// 5. PENGATURAN IKON DAN TAUTAN
// =====================================

$linkTypes = [
    "website" => [
        "icon" => "fa-globe",
        "style" => "solid"
    ],

    "whatsapp_channel" => [
        "icon" => "fa-bullhorn",
        "style" => "solid"
    ],

    "whatsapp_contact" => [
        "icon" => "fa-whatsapp",
        "style" => "brands"
    ]
];

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Fashion & Beauty | MySpace</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <style>
        body {
            background: #fff9fb;
            font-family: Arial, sans-serif;
            color: #493c43;
        }

        .page-header {
            background: linear-gradient(135deg, #f9dce8, #fff0f5);
            padding: 45px 20px;
            text-align: center;
            border-radius: 0 0 30px 30px;
        }

        .page-header h1 {
            font-weight: 700;
            color: #a94f78;
        }

        .page-header p {
            color: #765d69;
            margin-bottom: 0;
        }

        .category-card {
            background: white;
            border: 1px solid #f4dce6;
            border-radius: 20px;
            padding: 28px;
            height: 100%;
            box-shadow: 0 5px 20px rgba(180, 100, 135, 0.07);
            transition: 0.25s;
        }

        .category-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(180, 100, 135, 0.13);
        }

        .category-icon {
            width: 65px;
            height: 65px;
            background: #fff0f5;
            color: #c56b91;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 27px;
            margin-bottom: 20px;
        }

        .category-card h3 {
            font-size: 21px;
            font-weight: 700;
            color: #a94f78;
        }

        .category-card p {
            color: #83727b;
            min-height: 50px;
        }

        .action-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 14px;
            margin-top: 10px;
            border: 1px solid #f2dce5;
            border-radius: 12px;
            text-decoration: none;
            color: #765366;
            transition: 0.2s;
        }

        .action-link:hover {
            background: #fff0f5;
            color: #ad527b;
            border-color: #e8b8cc;
        }

        .action-link i {
            width: 22px;
            text-align: center;
            color: #c56b91;
        }

        .back-link {
            color: #a94f78;
            text-decoration: none;
            font-weight: 600;
        }

        .back-link:hover {
            color: #813858;
        }

        .empty-message {
            background: white;
            padding: 35px;
            border-radius: 18px;
            text-align: center;
            border: 1px solid #f4dce6;
        }

        @media(max-width: 768px) {
            .page-header {
                padding: 35px 15px;
            }

            .category-card {
                padding: 22px;
            }
        }
    </style>
</head>

<body>

<!-- =====================================
     HEADER
===================================== -->

<header class="page-header">

    <div class="container">

        <h1>Fashion & Beauty</h1>

        <p>
            Explore your style, discover inspiration,
            and take care of yourself.
        </p>

    </div>

</header>


<!-- =====================================
     MAIN CONTENT
===================================== -->

<main class="container py-5">

    <!-- KEMBALI KE DASHBOARD -->

    <div class="mb-4">

        <a href="dashboard.php" class="back-link">

            <i class="fa-solid fa-arrow-left me-2"></i>

            Kembali ke Dashboard

        </a>

    </div>


    <div class="row g-4">

        <?php if (empty($categories)): ?>

            <!-- JIKA BELUM ADA KATEGORI -->

            <div class="col-12">

                <div class="empty-message">

                    <i
                        class="fa-solid fa-heart fa-2x mb-3"
                        style="color:#c56b91;"
                    ></i>

                    <h4>Belum ada kategori tersedia</h4>

                    <p class="text-muted mb-0">
                        Silakan kunjungi kembali nanti.
                    </p>

                </div>

            </div>

        <?php else: ?>

            <?php foreach ($categories as $category): ?>

                <?php

                // Menentukan ikon kategori

                $icon = "fa-heart";

                if ($category["slug"] === "fashion-perempuan") {
                    $icon = "fa-person-dress";

                } elseif ($category["slug"] === "fashion-laki-laki") {
                    $icon = "fa-person";

                } elseif ($category["slug"] === "beauty") {
                    $icon = "fa-wand-magic-sparkles";
                }

                ?>

                <div class="col-lg-4 col-md-6">

                    <div class="category-card">

                        <!-- IKON KATEGORI -->

                        <div class="category-icon">

                            <i class="fa-solid <?= e($icon); ?>"></i>

                        </div>


                        <!-- NAMA KATEGORI -->

                        <h3>
                            <?= e($category["name"]); ?>
                        </h3>


                        <!-- DESKRIPSI -->

                        <p>
                            <?= e($category["description"]); ?>
                        </p>


                        <!-- DAFTAR TAUTAN -->

                        <?php foreach ($linkTypes as $type => $settings): ?>

                            <?php

                            $link = $category["links"][$type] ?? null;

                            if (!$link) {
                                continue;
                            }

                            $url = safeUrl($link["url"]);

                            if ($url === "") {
                                continue;
                            }

                            $iconClass = $settings["style"] === "brands"
                                ? "fa-brands"
                                : "fa-solid";

                            ?>

                            <a
                                href="<?= e($url); ?>"
                                class="action-link"
                                target="_blank"
                                rel="noopener noreferrer"
                            >

                                <i class="<?= e($iconClass); ?> <?= e($settings["icon"]); ?>"></i>

                                <span>
                                    <?= e($link["link_label"]); ?>
                                </span>

                                <i class="fa-solid fa-arrow-up-right-from-square ms-auto"></i>

                            </a>

                        <?php endforeach; ?>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

</main>

</body>
</html>
