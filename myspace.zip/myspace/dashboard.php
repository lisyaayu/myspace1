<?php
session_start();
require_once "config/database.php";

// Pastikan pengguna sudah login.
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int) $_SESSION["user_id"];

// Ambil data akun dan profil pengguna.
$stmt = mysqli_prepare(
    $conn,
    "SELECT
        u.name,
        u.username,
        u.email,
        u.role,
        p.photo,
        p.birth_date,
        p.bio,
        p.interests
     FROM users u
     LEFT JOIN profiles p ON p.user_id = u.id
     WHERE u.id = ?
     LIMIT 1"
);

if (!$stmt) {
    die("Terjadi kesalahan saat mengambil data pengguna.");
}

mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if (!$user) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}

// Perbarui informasi sesi.
$_SESSION["user_name"] = $user["name"];
$_SESSION["user_username"] = $user["username"];
$_SESSION["user_email"] = $user["email"];
$_SESSION["user_role"] = $user["role"];

// Token keamanan logout.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Helper keamanan output HTML.
function e($value): string
{
    return htmlspecialchars((string) ($value ?? ""), ENT_QUOTES, "UTF-8");
}

$name = e($user["name"]);
$username = e($user["username"]);
$email = e($user["email"]);

$first_name_raw = explode(" ", trim((string) $user["name"]))[0] ?? "there";
$first_name = e($first_name_raw);

$avatar_letter = strtoupper(substr((string) $user["name"], 0, 1));

// Foto profil yang diunggah melalui My Profile.
$profile_photo = trim((string) ($user["photo"] ?? ""));

// Batasi foto pada folder upload profil MySpace.
if (
    $profile_photo !== "" &&
    strpos($profile_photo, "assets/images/profiles/") !== 0
) {
    $profile_photo = "";
}

// Tanggal lahir.
$birth_date_display = "Belum ditambahkan";

if (!empty($user["birth_date"])) {
    try {
        $date = new DateTime($user["birth_date"]);
        $birth_date_display = $date->format("d F Y");
    } catch (Exception $exception) {
        $birth_date_display = "Belum ditambahkan";
    }
}

// Bio dan hobi.
$bio_display = trim((string) ($user["bio"] ?? ""));
$interests_display = trim((string) ($user["interests"] ?? ""));

// Menu dashboard.
$menus = [
    [
        "icon" => "fa-user",
        "title" => "My Profile",
        "description" => "Kenali dan kelola informasi profil pribadimu.",
        "color" => "pink",
        "link" => "profile.php",
        "available" => true
    ],
    [
        "icon" => "fa-brain",
        "title" => "Know Me",
        "description" => "Temukan kepribadian, minat, dan potensi dirimu.",
        "color" => "purple",
        "link" => "know_me.php",
        "available" => true
    ],
    [
        "icon" => "fa-shirt",
        "title" => "Fashion & Beauty",
        "description" => "Temukan inspirasi outfit dan tips kecantikan.",
        "color" => "peach",
        "link" => "fashion_beauty.php",
        "available" => true
    ],
    [
        "icon" => "fa-heart-pulse",
        "title" => "Health Center",
        "description" => "Dapatkan informasi kesehatan dan kesejahteraan.",
        "color" => "green",
        "link" => "health_center.php",
        "available" => true
    ],
    [
        "icon" => "fa-wallet",
        "title" => "My Finance",
        "description" => "Atur pemasukan, pengeluaran, dan tabungan.",
        "color" => "yellow",
        "link" => "my_finance.php",
        "available" => true
    ],
    [
  
        "icon" => "fa-book-open",
        "title" => "My Diary & Memories",
        "description" => "Simpan cerita kehidupan, pengalaman berharga, dan foto-foto kenangan favoritmu.",
        "color" => "mint",
        "link" => "diary.php",
        "available" => true
    ],

    [
        "icon" => "fa-heart",
        "title" => "Love & Relationship",
        "description" => "Pelajari hubungan sehat dan komunikasi.",
        "color" => "rose",
        "link" => "#",
        "available" => false
    ],
    [
        "icon" => "fa-calendar-check",
        "title" => "Manifestation & Planning",
        "description" => "Tempat merencanakan jadwal, target, impian, dan project yang ingin kamu wujudkan.",
        "color" => "blue",
        "link" => "#",
        "available" => false
    ],
    
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard | MySpace</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/dashboard.css">
</head>

<body>

<div class="dashboard-wrapper">

    <!-- SIDEBAR -->
    
<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">

    <!-- BRAND -->
    <a href="dashboard.php" class="sidebar-brand">
        <span class="brand-icon">
            <i class="fa-solid fa-heart"></i>
        </span>

        <span class="brand-name">
            MySpace<span class="brand-period">.</span>
        </span>
    </a>

    <!-- NAVIGATION -->
    <nav class="sidebar-menu">

        <div class="sidebar-section">
            <p class="menu-label">MAIN MENU</p>

            <a href="dashboard.php" class="sidebar-link active">
                <span class="sidebar-link-icon">
                    <i class="fa-solid fa-house"></i>
                </span>
                <span>Dashboard</span>
                <span class="active-indicator"></span>
            </a>

            <a href="#fitur" class="sidebar-link">
                <span class="sidebar-link-icon">
                    <i class="fa-solid fa-layer-group"></i>
                </span>
                <span>My Features</span>
            </a>

            <a href="profile.php" class="sidebar-link">
                <span class="sidebar-link-icon">
                    <i class="fa-regular fa-user"></i>
                </span>
                <span>My Account</span>
            </a>
        </div>

        <div class="sidebar-section personal-section">
            <p class="menu-label">PERSONAL SPACE</p>

            <a href="my_finance.php" class="sidebar-link">
                <span class="sidebar-link-icon">
                    <i class="fa-solid fa-wallet"></i>
                </span>
                <span>My Finance</span>
            </a>

            
            <a href="my_favorites.php" class="sidebar-link">
                <span class="sidebar-link-icon">
                    <i class="fa-solid fa-heart"></i>
                </span>
                <span>My Favorites</span>
            </a>


            <a href="#inspiration" class="sidebar-link">
                <span class="sidebar-link-icon">
                    <i class="fa-solid fa-seedling"></i>
                </span>
                <span>Self Growth</span>
            </a>

            <a href="diary.php" class="sidebar-link">
                <span class="sidebar-link-icon">
                    <i class="fa-solid fa-book-open"></i>
                </span>
                <span>My Memories</span>
            </a>
        </div>

    </nav>

    <!-- SIDEBAR BOTTOM -->
    <div class="sidebar-bottom">

        <div class="sidebar-user">

            <a href="profile.php" class="user-avatar">
                <?php if ($profile_photo !== ""): ?>
                    <img src="<?= e($profile_photo) ?>" alt="Profile">
                <?php else: ?>
                    <?= e($avatar_letter) ?>
                <?php endif; ?>
            </a>

            <div class="user-info">
                <strong title="<?= $name ?>">
                    <?= $name ?>
                </strong>

                <small title="<?= $email ?>">
                    <?= $email ?>
                </small>
            </div>

            <a href="profile.php" class="user-edit" title="Edit profile">
                <i class="fa-solid fa-pen"></i>
            </a>

        </div>

        <form action="logout.php" method="POST" id="logoutForm">
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($_SESSION["csrf_token"]) ?>"
            >

            <button
                type="button"
                class="logout-button"
                onclick="confirmLogout()"
            >
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Sign Out</span>
            </button>
        </form>

        <div class="sidebar-footer-note">
            Made with <i class="fa-solid fa-heart"></i> for you
        </div>

    </div>

</aside>


    <!-- MAIN CONTENT -->
    <main class="main-content">

        <!-- TOPBAR -->
        <header class="topbar">

            <button
                class="menu-toggle"
                type="button"
                onclick="toggleSidebar()"
                aria-label="Buka menu"
            >
                <i class="fa-solid fa-bars"></i>
            </button>

            <div class="topbar-title">
                <span class="topbar-eyebrow">
                    YOUR PERSONAL LIFE MANAGEMENT
                </span>
                <strong>My Dashboard</strong>
            </div>

            <div class="topbar-right">
                <div class="topbar-date">
                    <i class="fa-regular fa-calendar"></i>
                    <span id="currentDate"></span>
                </div>

                <a href="profile.php" class="topbar-avatar">
                    <?= e($avatar_letter) ?>
                </a>
            </div>

        </header>

        <div class="content-area">

            <!-- WELCOME BANNER -->
            <section class="welcome-banner">

                <div class="welcome-text">

                    <span class="welcome-label">
                        <i class="fa-solid fa-sparkles"></i>
                        YOUR LITTLE CORNER
                    </span>

                    <h1>
                        Hello, <?= $first_name ?>!
                        <span>♡</span>
                    </h1>

                    <p>
                        Selamat datang kembali di MySpace.
                        Ruang kecil untuk mengenal diri, merawat diri,
                        dan bertumbuh menjadi versi terbaik dirimu.
                    </p>

                    <a href="#fitur" class="welcome-button">
                        Explore MySpace
                        <i class="fa-solid fa-arrow-right"></i>
                    </a>

                </div>

                <!-- PROFILE PHOTO -->
                <a href="profile.php" class="welcome-profile">

                    <div class="profile-avatar-frame">

                        <?php if ($profile_photo !== ""): ?>

                            <?php
                            $photo_file = __DIR__ . "/" . $profile_photo;
                            $photo_version = is_file($photo_file)
                                ? filemtime($photo_file)
                                : time();
                            ?>

                            <img
                                src="<?= e($profile_photo) ?>?v=<?= $photo_version ?>"
                                alt="Foto profil <?= $name ?>"
                                class="welcome-profile-photo"
                            >

                        <?php else: ?>

                            <div class="default-avatar-art">
                                <span class="avatar-leaf leaf-left">✿</span>

                                <div class="avatar-face">
                                    <i class="fa-solid fa-heart"></i>
                                </div>

                                <span class="avatar-leaf leaf-right">✧</span>
                                <span class="avatar-caption">bloom beautifully</span>
                            </div>

                        <?php endif; ?>

                        <span class="avatar-edit">
                            <i class="fa-solid fa-camera"></i>
                        </span>

                    </div>

                    <span class="profile-photo-label">
                        MY PROFILE
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                    </span>

                </a>

                <div class="welcome-sparkle sparkle-a">✦</div>
                <div class="welcome-sparkle sparkle-b">♡</div>

                <!-- DATA PROFIL OTOMATIS -->
                <div class="welcome-personal-info">

                    <div class="personal-info-item">
                        <span>
                            <i class="fa-solid fa-cake-candles"></i>
                            BIRTHDAY
                        </span>

                        <strong><?= e($birth_date_display) ?></strong>
                    </div>

                    <div class="personal-info-item">
                        <span>
                            <i class="fa-solid fa-heart"></i>
                            HOBI & MINAT
                        </span>

                        <strong>
                            <?= e(
                                $interests_display !== ""
                                ? $interests_display
                                : "Belum ditambahkan"
                            ) ?>
                        </strong>
                    </div>

                    <div class="personal-info-item personal-bio">
                        <span>
                            <i class="fa-solid fa-feather"></i>
                            ABOUT ME
                        </span>

                        <strong>
                            <?= e(
                                $bio_display !== ""
                                ? $bio_display
                                : "Ceritakan sedikit tentang dirimu di My Profile ♡"
                            ) ?>
                        </strong>
                    </div>

                </div>

            </section>

            <!-- ACCOUNT SUMMARY -->
            <section class="summary-section" id="akun">

                <div class="section-heading">
                    <div>
                        <span class="section-kicker">A QUICK LOOK</span>
                        <h2>Your Account</h2>
                        <p>Informasi akun MySpace milikmu.</p>
                    </div>

                    <a href="profile.php" class="text-link">
                        Edit profile
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                    </a>
                </div>

                <div class="summary-grid">

                    <article class="summary-card">
                        <div class="summary-icon pink-icon">
                            <i class="fa-solid fa-user"></i>
                        </div>

                        <div class="summary-detail">
                            <span>Nama Pengguna</span>
                            <h3><?= $name ?></h3>
                        </div>
                    </article>

                    <article class="summary-card">
                        <div class="summary-icon purple-icon">
                            <i class="fa-solid fa-at"></i>
                        </div>

                        <div class="summary-detail">
                            <span>Username</span>
                            <h3>@<?= $username ?></h3>
                        </div>
                    </article>

                    <article class="summary-card">
                        <div class="summary-icon peach-icon">
                            <i class="fa-solid fa-envelope"></i>
                        </div>

                        <div class="summary-detail">
                            <span>Email Address</span>
                            <h3><?= $email ?></h3>
                        </div>
                    </article>

                </div>

            </section>

            <!-- FEATURES -->
            <section class="features-section" id="fitur">

                <div class="section-heading">
                    <div>
                        <span class="section-kicker">MADE FOR YOU</span>
                        <h2>Explore Your Space</h2>
                        <p>Semua kebutuhan personalmu dalam satu tempat.</p>
                    </div>

                    <span class="feature-count">
                        <i class="fa-solid fa-sparkles"></i>
                        8 Features
                    </span>
                </div>

                <div class="features-grid">

                    <?php foreach ($menus as $menu): ?>

                        <?php if ($menu["available"]): ?>

                            <a
                                href="<?= e($menu["link"]) ?>"
                                class="feature-card feature-card-link"
                            >

                                <div class="feature-card-top">
                                    <div class="feature-icon <?= e($menu["color"]) ?>">
                                        <i class="fa-solid <?= e($menu["icon"]) ?>"></i>
                                    </div>

                                    <span class="feature-arrow">
                                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                    </span>
                                </div>

                                <h3><?= e($menu["title"]) ?></h3>
                                <p><?= e($menu["description"]) ?></p>

                                <span class="feature-action">
                                    Explore now
                                    <i class="fa-solid fa-arrow-right"></i>
                                </span>

                            </a>

                        <?php else: ?>

                            <article class="feature-card feature-card-disabled">

                                <div class="feature-card-top">
                                    <div class="feature-icon <?= e($menu["color"]) ?>">
                                        <i class="fa-solid <?= e($menu["icon"]) ?>"></i>
                                    </div>

                                    <span class="coming-soon">Coming soon</span>
                                </div>

                                <h3><?= e($menu["title"]) ?></h3>
                                <p><?= e($menu["description"]) ?></p>

                                <span class="feature-action muted-action">
                                    <i class="fa-regular fa-clock"></i>
                                    Coming soon
                                </span>

                            </article>

                        <?php endif; ?>

                    <?php endforeach; ?>

                </div>

            </section>

            <!-- INSPIRATION -->
            <section class="inspiration-banner" id="inspiration">

                <div class="inspiration-mark">
                    <i class="fa-solid fa-quote-left"></i>
                </div>

                <div class="inspiration-copy">
                    <span class="section-kicker">A LITTLE REMINDER</span>

                    <h2>
                        “Small steps every day lead to big changes.”
                    </h2>

                    <p>
                        Tidak perlu menjadi sempurna.
                        Cukup terus berkembang dan hargai setiap prosesmu.
                    </p>
                </div>

                <div class="inspiration-flower">✿</div>

            </section>

            <!-- FOOTER -->
            <footer class="dashboard-footer">
                <span>
                    © <?= date("Y") ?> MySpace.
                </span>

                <span>
                    Made with
                    <i class="fa-solid fa-heart"></i>
                    for your journey.
                </span>
            </footer>

        </div>

    </main>

</div>

<!-- MOBILE SIDEBAR OVERLAY -->
<div
    class="sidebar-overlay"
    id="sidebarOverlay"
    onclick="toggleSidebar()"
></div>

<!-- LOGOUT MODAL -->
<div
    class="logout-modal"
    id="logoutModal"
    role="dialog"
    aria-modal="true"
    aria-labelledby="logoutTitle"
>

    <div class="logout-modal-card">

        <div class="modal-icon">
            <i class="fa-solid fa-right-from-bracket"></i>
        </div>

        <h3 id="logoutTitle">Logout from MySpace?</h3>

        <p>
            Apakah kamu yakin ingin keluar dari akun MySpace?
        </p>

        <div class="modal-actions">
            <button
                type="button"
                class="cancel-button"
                onclick="closeLogoutModal()"
            >
                Cancel
            </button>

            <button
                type="button"
                class="confirm-button"
                onclick="submitLogout()"
            >
                Yes, Logout
            </button>
        </div>

    </div>

</div>

<script>
function toggleSidebar() {
    document.getElementById("sidebar").classList.toggle("show");
    document.getElementById("sidebarOverlay").classList.toggle("show");
}

function confirmLogout() {
    document.getElementById("logoutModal").classList.add("show");
}

function closeLogoutModal() {
    document.getElementById("logoutModal").classList.remove("show");
}

function submitLogout() {
    document.getElementById("logoutForm").submit();
}

// Tanggal hari ini.
const dateElement = document.getElementById("currentDate");

if (dateElement) {
    dateElement.textContent = new Date().toLocaleDateString("id-ID", {
        day: "numeric",
        month: "long",
        year: "numeric"
    });
}

// Tutup modal jika klik area luar.
document.getElementById("logoutModal").addEventListener("click", function(event) {
    if (event.target === this) {
        closeLogoutModal();
    }
});

// Tutup modal dengan tombol Escape.
document.addEventListener("keydown", function(event) {
    if (event.key === "Escape") {
        closeLogoutModal();
    }
});
</script>

</body>
</html>
